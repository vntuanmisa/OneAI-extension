// Cấu hình đồng bộ API
// Lưu ý: API_SECRET_KEY nằm ở client sẽ có thể bị lộ. Chỉ dùng cho mục đích demo/không quan trọng.
export const API_BASE_URL = 'https://one-ai-extension-mkwh339q0-amismakts-projects.vercel.app/api/data';
export const API_SECRET_KEY = 'b75d8f44f4d54d1abf1d8fc3d1e0b9a3';


